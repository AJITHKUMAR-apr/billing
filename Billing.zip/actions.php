<?php

function clean($idata) {
    if (!empty($idata) && is_string($idata)) {
        return str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '', "\\'", '\\"', '\\Z'), $idata);
    }

    return $idata;
}

function post($pdata) {
    return isset($_POST[$pdata]) ? $_POST[$pdata] : '';
}

function GetArrayValue($str, $lab) {
    if (isset($str[$lab])) {
        return $str[$lab];
    } else {
        return "";
    }
}

function Response($status, $status_message, $data) {
    header("HTTP/1.1 " . $status);

    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;

    $json_response = json_encode($response);
    echo $json_response;
    exit();
}

$action = clean(post('action'));
if ($action == "addNewItem") {
    $name = clean(post('item_name'));
    $qty = clean(post('item_qty'));
    $unitPrice = clean(post('item_up'));
    $tax = clean(post('tax'));

    $item = [];
    $item['name'] = $name;
    $item['quantity'] = $qty;
    $item['unit_price'] = $unitPrice;
    $item['tax'] = $tax;
    $item['total'] = $qty * $unitPrice;
    $item['total_with_tax'] = ($qty * $unitPrice) + ($tax * $qty * $unitPrice / 100);

    if (!file_exists("./itemList.json")) {
        $list = [];
        $listData = [];
        array_push($list, $item);
        $listData['data'] = $list;
        $fp = fopen("./itemlist.json", 'w');
        fwrite($fp, json_encode($listData, JSON_PRETTY_PRINT));
        fclose($fp);
    } else {
        $fileData = file_get_contents("./itemlist.json");
        $jsonData = json_decode($fileData, true);
        array_push($jsonData['data'], $item);
        $fp = fopen("./itemlist.json", 'w');
        fwrite($fp, json_encode($jsonData, JSON_PRETTY_PRINT));
        fclose($fp);
    }
    Response(200, "success", []);
} else if ($action == "getInvoiceData") {
    $fileData = file_get_contents("./itemlist.json");
    $jsonData = json_decode($fileData, true);
    Response(200, "success", $jsonData);
} else if ($action == "applyDiscount") {
    $discount = clean(post('discount'));
    $fileData = file_get_contents("./itemlist.json");
    $jsonData = json_decode($fileData, true);
    $subTotal = 0;
    foreach ($jsonData['data'] as $item) {
        $subTotal = $subTotal + GetArrayValue($item, 'total_with_tax');
    }
    $jsonData['discount'] = $discount;
    $jsonData['grand_total'] = $subTotal - $discount;
    $fp = fopen("./itemlist.json", 'w');
    fwrite($fp, json_encode($jsonData, JSON_PRETTY_PRINT));
    fclose($fp);
    Response(200, "success", []);
} else if ($action == "createNew") {
    unlink("./itemlist.json");
    Response(200, "success", []);
} else {
    Response(200, 'unknown action', []);
}