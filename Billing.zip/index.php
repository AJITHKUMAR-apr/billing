<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Billing System</title>
        <link rel="stylesheet" href="./css_lib/foundation.min.css"/>
        <style type="text/css">
            .body-bg{
                background-color: #E0F2FF;
            }
            .item-center{
                text-align: center;
            }
            .button{
                border-radius: 5px;
                background-color: #00cec9;
            }
            .button.red{
                background-color: #e17055;
            }
            .button.red:hover{
                background-color: #d63031;
            }
            .hidden{
                display: none;
            }
            .missing-value input, .missing-value textarea, .missing-value select{
                border-color: #e74c3c;
            }
            .bg-alert{
                background-color: #fab1a0;
            }
            .bg-success{
                background-color: #81ecec;
            }
            button a,button a:hover  {
                color: white;
            }
        </style>
    </head>
    <body class="body-bg">
        <div class="grid-x fluid" >
            <div class="cell large-4 large-offset-4 ">
                <h5 class="text-center">Billing System</h5>
                <div class="text-right">
                    <button class="button" id="add-item-button" type="button" onclick="$(this).addClass('hidden');$('#addNewitemForm').removeClass('hidden');">Add new item</button>
                </div>
                <form id="addNewitemForm" class="hidden grid-x grid-margin-x" onsubmit="return AddItem($(this));" >
                    <b class="cell"> Add an item </b>
                    <label class="cell item-required" >
                        Name
                        <input type="text" name="item_name" placeholder="Name"/>
                    </label>
                    <label class="cell large-4 item-required" >
                        Quantity
                        <input type="number" name="item_qty" placeholder="Quantity"/>
                    </label>
                    <label class="cell large-4 item-required" >
                        Unit Price($)
                        <input type="number" name="item_up" placeholder="Unit Price($)"/>
                    </label>
                    <label class="cell large-4 item-required" >
                        Tax
                        <select name="tax">
                            <option value="">-select-</option>
                            <option value="0"> 0% </option>
                            <option value="1"> 1% </option>
                            <option value="5"> 5% </option>
                            <option value="10"> 10% </option>
                        </select>
                    </label>
                    <input type="hidden" name="action" value="addNewItem"/>
                    <div class="cell text-right">
                        <button type="button" class="button red" onclick="$('#addNewitemForm').addClass('hidden');$('#add-item-button').removeClass('hidden');" >Cancel</button>
                        <button type="submit" class="button" >Add</button>
                    </div>
                    <div class="resp callout hidden cell item-center">test</div>
                </form>
                <div class="item-center">
                    <table class="unstriped stack hover">
                        <thead >
                            <tr>
                                <th width="20">SL No</th>
                                <th >Name</th>
                                <th >Quantity</th>
                                <th >Unit Prize ($)</th>
                                <th >Tax (%)</th>
                                <th >Total&nbsp;(Tax inclusive)</th>
                                <th >Total</th>
                            </tr>
                        </thead>
                        <tbody id="invoice-table" ></tbody>
                    </table>
                </div>
                <div >
                    <form class="grid-x grid-margin-x" onsubmit="return applyDiscount();">
                        <label class="cell large-6">
                            Discount($)
                            <input type="number" id="discount" name="discount" placeholder="Discount ($)" min="0"/>
                        </label>
                        <div class="cell large-6">
                            <button class="button" type="submit" style="margin-top: 22px;margin: 22px 0 0 0;" >Apply</button>
                        </div>
                        <div class="response callout hidden cell item-center">test</div>
                    </form>
                </div>
                <div class="text-right">
                    <button class="button" type="button"  onclick=""><a href="invoice" target="_blank">Generate Invoice</a></button>
                    <button class="button float-left" type="button" onclick="createNew()">Create a new Invoice</button>
                </div>
            </div>
        </div>
        <script src="js_lib/main/jquery.min.js"></script>
        <script src="js_lib/main/foundation.min.js"></script>
        <script type="text/javascript">
                        $(document).ready(function () {
                            getInvoiceData();
                        });
                        function AddItem(formElement) {
                            var fieldsFilled = true;
                            formElement.find('.item-required').each(function () {
                                if ($(this).find('input').val() === '' || $(this).find('select').val() === '') {
                                    $(this).addClass('missing-value');
                                    fieldsFilled = false;

                                } else {
                                    $(this).removeClass('missing-value');
                                }
                            });
                            if (!fieldsFilled) {
                                formElement.find('.resp').removeClass('hidden').addClass('bg-alert').removeClass('bg-success').html('Please fill missing fields to continue');
                                return false;
                            }

                            $.post('http://localhost/billing/actions', formElement.serialize(), function (data) {
                                if (data && data.status_message === 'success') {
                                    formElement.find('.resp').removeClass('hidden').addClass('bg-success').removeClass('bg-alert').html('success');
                                } else {
                                    formElement.find('.resp').removeClass('hidden').addClass('bg-alert').removeClass('bg-success').html('Something went wrong.Please try again later.');
                                }
                                setTimeout(function () {
                                    getInvoiceData();
                                    $('.resp').slideUp();
                                }, 1500);
                            }, 'json');

                            return false;
                        }

                        function getInvoiceData() {
                            $.post('http://localhost/billing/actions', {action: "getInvoiceData"}, function (data) {
                                if (data && data.status_message === "success") {
                                    console.log((data.data));
                                    populateTable(data.data)
                                } else {
                                    console.error('failed to fetch invoice data');
                                }
                            }, 'json');
                        }

                        function populateTable(data) {
                            $('#invoice-table').empty();
                            var slNo = 1;
                            var subTotal = 0;
                            var subTotalWithTax = 0;
                            for (var item in data.data) {
                                var singleItemData = data['data'][item];
                                var name = singleItemData['name'];
                                var quantity = singleItemData['quantity'];
                                var tax = singleItemData['tax'];
                                var unit_price = singleItemData['unit_price'];
                                var total = singleItemData['total'];
                                var total_with_tax = singleItemData['total_with_tax'];
                                $('#invoice-table').append("<tr>"
                                        + "<td>" + slNo + "</td>"
                                        + "<td>" + name + "</td>"
                                        + "<td>" + quantity + "</td>"
                                        + "<td>" + unit_price + "</td>"
                                        + "<td>" + tax + "</td>"
                                        + "<td>" + total + "</td>"
                                        + "<td>" + total_with_tax + "</td>"
                                        + "</tr>");
                                slNo++;
                                subTotal += total;
                                subTotalWithTax += total_with_tax;
                            }
                            var discount = data['discount'];
                            $('#invoice-table').append("<tr>"
                                    + "<td colspan='5' style='text-align: right;'><b>Sub Total</b></td>"
                                    + "<td>" + subTotal + "</td>"
                                    + "<td>" + subTotalWithTax + "</td>"
                                    + "</tr>");
                            if (discount) {
                                $('#invoice-table').append("<tr style='height:15px;'></tr><tr>"
                                        + "<td colspan='6' style='text-align: right;'><b>Discount &nbsp; ($)</b></td>"
                                        + "<td>" + discount + "</td>"
                                        + "</tr>");
                                $('#invoice-table').append("<tr>"
                                        + "<td colspan='6' style='text-align: right;'><b>Grand Total &nbsp; ($)</b></td>"
                                        + "<td>" + (subTotalWithTax - discount) + "</td>"
                                        + "</tr>");
                            }

                        }

                        function applyDiscount() {
                            $.post('http://localhost/billing/actions', {action: "applyDiscount", discount: $('#discount').val()}, function (data) {
                                if (data && data.status_message === "success") {
                                    $('.response').removeClass('hidden').addClass('bg-success').removeClass('bg-alert').html('success');
                                } else {
                                    $('.response').removeClass('hidden').addClass('bg-alert').removeClass('bg-success').html('Something went wrong.Please try again later.');
                                }
                                setTimeout(function () {
                                    getInvoiceData();
                                    $('.response').slideUp();
                                }, 1500);
                            }, 'json');
                            return false;
                        }

                        function createNew() {
                            $.post('http://localhost/billing/actions', {action: "createNew"}, function (data) {
                                location.reload();
                            });
                            return false;
                        }
        </script>
    </body>
</html>
