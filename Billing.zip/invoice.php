<?php
$fileData = file_get_contents("./itemlist.json");
$jsonData = json_decode($fileData, true);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Billing System</title>
        <link rel="stylesheet" href="./css_lib/foundation.min.css"/>
    </head>
    <body class="body-bg">
        <div class="grid-x fluid" >
            <div class="cell large-4 large-offset-4" style="text-align: center;">
                <div class="text-center">
                    <h3>INVOICE</h3>
                </div>
                <div class="text-left" style="margin-bottom: 20px;">
                    <span><b>XYZ Company</b></span><br>
                    <span><b>Kerala,India</b></span>
                </div>
                <table class="unstriped stack hover">
                    <thead >
                        <tr>
                            <th width="20">SL No</th>
                            <th >Name</th>
                            <th >Quantity</th>
                            <th >Unit Prize ($)</th>
                            <th >Tax (%)</th>
                            <th >Total&nbsp;(Tax inclusive)</th>
                            <th >Total</th>
                        </tr>
                    </thead>
                    <tbody id="invoice-table" >
                        <?php
                        $i = 1;
                        $total = 0;
                        $total_with_tax = 0;
                        foreach ($jsonData['data'] as $item) {
                            echo '<tr><td>' . $i . '</td>';
                            echo '<td>' . $item['name'] . '</td>';
                            echo '<td>' . $item['quantity'] . '</td>';
                            echo '<td>' . $item['unit_price'] . '</td>';
                            echo '<td>' . $item['tax'] . '</td>';
                            echo '<td>' . $item['total'] . '</td>';
                            echo '<td>' . $item['total_with_tax'] . '</td></tr>';
                            $total_with_tax += $item['total_with_tax'];
                            $total += $item['total'];
                            $i++;
                        }
                        echo '<tr ><td colspan="5" style="text-align: right;"><b>Sub Total</b></td><td>' . $total . '</td><td>' . $total_with_tax . '</td>';
                        echo '<tr ><td colspan="6" style="text-align: right;"><b>Discount ($)</b></td><td>' . $jsonData['discount'] . '</td>';
                        echo '<tr ><td colspan="6" style="text-align: right;"><b>Grant Total ($)</b></td><td>' . ($total_with_tax - $jsonData['discount']) . '</td>';
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>