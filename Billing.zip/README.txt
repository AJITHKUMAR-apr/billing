To host on WAMP
	1.Create a folder named 'billing' on your www folder of wamp.
	2.Extract the zip inside folder billing.
	3.Open any browser and go to 'http://localhost/billing/'
	
	Note:Make sure that Apche server is running and PHP is installed.
